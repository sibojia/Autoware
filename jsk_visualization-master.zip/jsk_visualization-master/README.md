jsk_visualization
=================
 [![Build Status](https://travis-ci.org/jsk-ros-pkg/jsk_visualization.svg?branch=master)](https://travis-ci.org/jsk-ros-pkg/jsk_visualization)
[![Read the Docs](https://readthedocs.org/projects/pip/badge/?version=latest)](https://jsk-visualization.readthedocs.org)
jsk visualization ros packages

see [read the docs](http://jsk-visualization.readthedocs.org/en/latest/)

Deb Build Status
----------------

| Package | Indigo (Saucy) | Indigo (Trusty) |
|--------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| jsk_visualization (32-bit) | [![Build Status](http://build.ros.org/job/Ibin_uS32__jsk_visualization__ubuntu_saucy_i386__binary/badge/icon)](http://build.ros.org/job/Ibin_uS32__jsk_visualization__ubuntu_saucy_i386__binary/) | [![Build Status](http://build.ros.org/job/Ibin_uT32__jsk_visualization__ubuntu_trusty_i386__binary/badge/icon)](http://build.ros.org/job/Ibin_uT32__jsk_visualization__ubuntu_trusty_i386__binary/) |
| jsk_visualization (64-bit) | [![Build Status](http://build.ros.org/job/Ibin_uS64__jsk_visualization__ubuntu_saucy_amd64__binary/badge/icon)](http://build.ros.org/job/Ibin_uS64__jsk_visualization__ubuntu_saucy_amd64__binary/) | [![Build Status](http://build.ros.org/job/Ibin_uT64__jsk_visualization__ubuntu_trusty_amd64__binary/badge/icon)](http://build.ros.org/job/Ibin_uT64__jsk_visualization__ubuntu_trusty_amd64__binary/) |
