=================
jsk_visualization
=================

jsk_visualization is a stack for the visualization packages which are used in JSK lab.

The code is open source, and `available on github`_.

.. _available on github: http://github.com/jsk-ros-pkg/jsk_visualization


This repository contains following ros packages:


.. toctree::
   :maxdepth: 1

   jsk_rviz_plugins/index
   jsk_rqt_plugins/index
   jsk_interactive_marker/index
   tips/index
