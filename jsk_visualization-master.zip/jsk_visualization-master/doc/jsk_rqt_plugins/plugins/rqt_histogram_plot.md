# rqt\_histogram\_plot
![](images/rqt_histogram_plot.gif)

Plot histogram data. It supported array fields of topics and `jsk_recognition_msgs/HistogramWithRange`.
If you want to specify x-values of figure, use `jsk_recognition_msgs/HistogramWithRange`.

