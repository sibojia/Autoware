# rqt\_2d\_plot
![](images/rqt_2d_plot.png)

Plot `jsk_recognition_msgs/PlotData` as scatter plot.

