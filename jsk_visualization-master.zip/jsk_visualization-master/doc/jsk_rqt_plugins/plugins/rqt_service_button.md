# rqt\_service\_button
![](images/rqt_service_button.png)

Generate service buttons according to the configuration written in yaml file.
(sample yaml file: `jsk_rqt_plugins/resource/service_button_layout.yaml`)

