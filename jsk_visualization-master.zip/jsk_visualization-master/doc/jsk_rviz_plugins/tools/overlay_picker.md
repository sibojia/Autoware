# OverlayPickerTool
It is a tool to move overlay plugins interactively.

![](images/overlay_picker.gif)

If you drag overlay widget with pressing `Shift` key,
the widget is aligned to grid.
