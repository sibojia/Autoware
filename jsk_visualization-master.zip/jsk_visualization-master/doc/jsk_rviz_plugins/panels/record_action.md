# RecordAction
![RecordAction](images/record_action.png)

This will publish jsk_rviz_plugins/RecordCommand to /record_command.
Set the target name.
