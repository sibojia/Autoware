# PublishTopic
![PublishTopic](images/publish_topic.png)

This will publish std_msgs/Empty to the topic you designate.
