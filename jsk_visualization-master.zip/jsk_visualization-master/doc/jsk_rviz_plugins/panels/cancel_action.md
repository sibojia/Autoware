# CancelAction
![CancelAction](images/cancel_action.png)

This will publish action_msg/GoalID to `topic_name`/cancel.
You can choose multiple cancel goals.
