# ObjectFitOperatorAction
![ObjectFitOperatorAction](images/object_fit_operator_action.png)

This will publish jsk_rviz_plugins/ObjectFitCommand to /object_fit_command".
If you check `reversed`, the reversed version will publish.
