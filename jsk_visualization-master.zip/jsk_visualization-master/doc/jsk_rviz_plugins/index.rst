================
jsk_rviz_plugins
================

jsk\_rviz\_plugins is a package to provide original rviz plugins.

You can use this rviz plugins just launch rviz.


.. toctree::
   :glob:
   :maxdepth: 1
   :caption: plugins

   ./plugins/*

.. toctree::
   :glob:
   :maxdepth: 1
   :caption: panels

   ./panels/*
.. toctree::
   :glob:
   :maxdepth: 1
   :caption: tools

   ./tools/*
