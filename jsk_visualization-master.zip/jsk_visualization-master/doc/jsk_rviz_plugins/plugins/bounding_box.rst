BoundingBox
===========

What is this?
-------------

Visualize ``jsk_recognition_msgs/BoundingBox.msg``.

.. image:: images/bounding_box.png
