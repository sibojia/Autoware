# Plotter2D
Plot a line graph of `std_msgs/Float32` on rviz as HUD Display.

![](images/plotter_2d.png)

## Sample
```
roslaunch jsk_rviz_plugins overlay_sample.launch
```
