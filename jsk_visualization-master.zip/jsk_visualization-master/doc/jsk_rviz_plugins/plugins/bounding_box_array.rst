BoundingBoxArray
================

What is this?
-------------

Visualize ``jsk_recognition_msgs/BoundingBoxArray.msg``.

.. image:: images/bounding_box_array.png
