# TFTrajectory
![https://youtu.be/d9YZWJ5bBZ8](images/tf_trajectory.png)

Visualize trajectory of a tf frame.
