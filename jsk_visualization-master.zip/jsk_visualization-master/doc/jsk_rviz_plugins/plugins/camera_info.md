# CameraInfo
Visualize `sensor_msgs/CameraInfo`.

![](images/camera_info.png)

![](images/camera_info_line.png)
