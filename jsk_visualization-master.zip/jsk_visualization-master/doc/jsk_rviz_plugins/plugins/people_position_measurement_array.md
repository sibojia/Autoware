# PeoplePositionMeasuermentArray
It visualizes [`people_msgs/PositionMeasuermentArray`](http://docs.ros.org/indigo/api/people_msgs/html/msg/PositionMeasurementArray.html).

[![](images/people_position_measurement_array.png)](https://www.youtube.com/watch?v=u2WXZ0Rydtg)
