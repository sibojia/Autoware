Footstep
========

What is this?
-------------

Visualize ``jsk_footstep_msgs/Footstep.msg``.

.. image:: images/footstep.png
