# OverlayText
Draw text of [`jsk_rviz_plugins/OverlayText`](http://docs.ros.org/indigo/api/jsk_rviz_plugins/html/msg/OverlayText.html) on rviz as HUD overlay.

![](images/overlay_text.png)

## Sample
```
roslaunch jsk_rviz_plugins overlay_sample.launch
```
