# VideoCapture
VideoCapture plugin can capture video of rviz.

![](images/video_capture.png)

You need to specify valid filename and fps before capture video.
After that, toggle start capture checkbox and the movie is recored until you uncheck the checkbox.

Be carefull on creating too large video.
