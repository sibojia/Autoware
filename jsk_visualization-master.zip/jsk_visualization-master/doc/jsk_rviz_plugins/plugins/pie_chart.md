# PieChart
Plot a pie chart of `std_msgs/Float32` on rviz as HUD overlay.

![](images/pie_chart.png)

## Sample
```
roslaunch jsk_rviz_plugins overlay_sample.launch
```
