# SimpleOccupancyGridArray
![](images/simple_occupancy_grid_array.png)

Visualize `jsk_recognition_msgs/SimpleOccupancyGridArray`.
